/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pcscg9.sem1zoologico;

/**
 *
 * @author deiv
 */
public class TigrePigmeo extends Tigre {
    int estaturaTigre;
    
    public TigrePigmeo(String nombre, int estatura)
    {
        this(nombre);
        this.estaturaTigre = estatura;
    }
    
    public TigrePigmeo(String nombre)
    {
        super(nombre); //Este constructor con la llamada al SUPER es indispensable para la comunicación entre clases
                       // piincipales y secundarias.
    }
}
