/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pcscg9.sem1zoologico;

/**
 *
 * @author deiv
 */
public class Sem1Zoologico {

    public static void main(String[] args) {
        //Vamos a construir un objeto de tipo Tigre
        
        System.out.println("*TIGRES DEL ZOOLOGICO*");
        
        //Esta es una instancia de Tigre, que nos genera un objeto de ese tipo
                        //Llamada al constructor
        Tigre unTigre = new Tigre("Tony"); //Este tigre está almacenado en el espacio de memoria A
        
        //Vamos a crear otro objeto de tipo Tigre
        
        Tigre otroTigre = new Tigre("Lorenzo"); //Este tigre está almacenado en el espacio de memoria B
        
        Tigre tercerTigre = new Tigre("Toby"); //Este tigre está almacenado en el espacio de memoria C
        
        tercerTigre = otroTigre; //Liberamos el espacio de memoria C y tanto tercerTigre como otroTigre apuntan al espacio
                                 // de memoria B
                                
        Tigre.existenTigres();
        System.out.println("Hola soy un tigre y me llamo: " + unTigre.getNombre());
        System.out.println("Hola soy otro tigre y me llamo: " + otroTigre.getNombre());
    }
}
